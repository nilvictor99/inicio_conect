<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "usuario";

$conn = mysqli_connect($dbhost, $dbuser, $dbpassword, $dbname);
if (!$conn) {
    die("No hay conexión: " . mysqli_connect_error());
}

$username = $_POST["username"];
$password = $_POST["password"];

// Corrección en la consulta SQL
$query = mysqli_query($conn, "SELECT * FROM login where usuario = '".$username."' and password = '".$password."'");
$nr = mysqli_num_rows($query);

if ($nr == 1) {
    // Redireccionar a la página de bienvenida
    header("Location: capa_bienvenida/bienvenida.html");
    exit();
} else {
    echo "No ingresó";
}
?>