<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "usuario";
$port ="3306";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname, $port );

// Verificar conexión
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Datos a ingresar en la base de datos
$firstname = "John";
$lastname = "Doe";
$email = "john@example.com";

// Insertar datos en la base de datos
$sql = "INSERT INTO  registro_de_usurios(usuario, password) VALUES ('$usuario', '$password')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Cerrar conexión
$conn->close();
?>